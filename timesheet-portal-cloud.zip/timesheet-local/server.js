'use strict';
/* Timesheet Portal: self-hosted server. No npm packages needed (Node 18+). */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = +process.env.PORT || 3000, HOST = process.env.HOST || '0.0.0.0';
const DIR = process.env.DATA_DIR || path.join(__dirname, 'data'), FILE = path.join(DIR, 'db.json'), PUB = path.join(__dirname, 'public');
fs.mkdirSync(DIR, { recursive: true });

let DB = { users: [], sheets: [], sessions: {} };
if (fs.existsSync(FILE)) DB = JSON.parse(fs.readFileSync(FILE, 'utf8'));
function save() { const t = FILE + '.tmp'; fs.writeFileSync(t, JSON.stringify(DB)); fs.renameSync(t, FILE); }

const err = (code, msg) => Object.assign(new Error(msg), { code });
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, hash: crypto.scryptSync(pw, salt, 64).toString('hex') });
const checkPw = (pw, u) => { const a = crypto.scryptSync(pw, u.salt, 64), b = Buffer.from(u.hash, 'hex'); return a.length === b.length && crypto.timingSafeEqual(a, b); };

/* ---------- first-run seed ---------- */
const rnd = () => crypto.randomBytes(9).toString('base64url');
const ADMIN_PW = process.env.ADMIN_PASSWORD || rnd(), INIT_PW = process.env.INITIAL_PASSWORD || rnd();
const SECURE = process.env.COOKIE_SECURE === '1';
const clientIp = req => (process.env.TRUST_PROXY === '1' && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress;
if (!DB.users.length) {
  const mk = (username, pw, role, name, designation, project, supervisorId) => {
    const u = { id: crypto.randomUUID(), username, role, name, designation, project, supervisorId: supervisorId || null, sig: null, mustChange: true, createdAt: Date.now(), ...hashPw(pw) };
    DB.users.push(u); return u;
  };
  const P1 = 'Enhancing Climate Change and Food Security Project (ECRFS project)';
  const P2 = 'Toward Risk-Aware and Climate-resilienT communities (TRACT) project';
  mk('admin', ADMIN_PW, 'admin', 'Administrator', '', '');
  if (process.env.SEED_SAMPLE === '0') { save(); console.log('First run: admin account created.' + (process.env.ADMIN_PASSWORD ? '' : ' Admin password: ' + ADMIN_PW)); }
  else {
  const s1 = mk('hamdhaan', INIT_PW, 'supervisor', 'Mohamed Hamdhaan Zuhair', 'Project Manager', P1);
  const s2 = mk('hamdhoon', INIT_PW, 'supervisor', 'Mohamed Hamdhoon', 'Project Manager', P2);
  mk('aiham', INIT_PW, 'staff', 'Abdulla Aiham Mohamed', 'Procurement Specialist', P1, s1.id);
  mk('mariyam', INIT_PW, 'staff', 'Mariyam Fazula', 'Procurement Officer', P2, s2.id);
  save();
  console.log('First run: created admin and sample users (aiham, mariyam, hamdhaan, hamdhoon). Everyone must change password on first login.');
  if (!process.env.ADMIN_PASSWORD) console.log('Admin password: ' + ADMIN_PW);
  if (!process.env.INITIAL_PASSWORD) console.log('Initial password for the other users: ' + INIT_PW);
  }
}

/* ---------- helpers ---------- */
const D = /^\d{4}-\d{2}-\d{2}$/, T = /^([01]\d|2[0-3]):[0-5]\d$/;
const mins = t => { if (!T.test(t)) return 0; const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const spent = r => (!r || r.off || !r.start || !r.end) ? 0 : Math.max(0, mins(r.end) - mins(r.start));
function dayList(ps, pe) { const o = []; for (let a = Date.parse(ps + 'T00:00:00Z'), b = Date.parse(pe + 'T00:00:00Z'); a <= b && o.length < 63; a += 864e5) o.push(new Date(a).toISOString().slice(0, 10)); return o; }
const total = t => dayList(t.ps, t.pe).reduce((s, d) => s + spent((t.rows || {})[d]), 0);
function cleanSheet(b) {
  if (!D.test(b.ps) || !D.test(b.pe) || isNaN(Date.parse(b.ps)) || isNaN(Date.parse(b.pe)) || b.pe < b.ps) throw err(400, 'Invalid period');
  const days = dayList(b.ps, b.pe); if (days.length > 62) throw err(400, 'Period too long');
  const rows = {}; for (const d of days) { const r = (b.rows || {})[d] || {}; rows[d] = { detail: String(r.detail || '').slice(0, 200), start: T.test(r.start) ? r.start : '', end: T.test(r.end) ? r.end : '', off: !!r.off }; }
  return { ps: b.ps, pe: b.pe, req: Math.min(744, Math.max(0, +b.req || 0)), pdate: D.test(b.pdate) ? b.pdate : '', rows };
}
const byId = id => DB.users.find(u => u.id === id);
function pub(u, withSig) {
  const o = { id: u.id, username: u.username, role: u.role, name: u.name, designation: u.designation, project: u.project, supervisorId: u.supervisorId, mustChange: !!u.mustChange, hasSig: !!u.sig };
  if (u.role === 'staff') { const s = byId(u.supervisorId); o.supervisorName = s ? s.name : ''; o.supDes = s ? s.designation : ''; }
  if (withSig) o.sig = u.sig; return o;
}
const summary = t => ({ id: t.id, ownerId: t.ownerId, staffName: t.staffName, supervisorName: t.supervisorName, project: t.project, ps: t.ps, pe: t.pe, status: t.status, total: total(t), updatedAt: t.updatedAt });
const canSee = (u, t) => u.role === 'admin' ? t.status !== 'draft' : t.ownerId === u.id || (u.role === 'supervisor' && t.status !== 'draft' && t.project === u.project);
const wait = (res, c, o) => { res.writeHead(c, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(o)); };

function sessionUser(req) {
  const m = /(?:^|;\s*)sid=([a-f0-9]{64})/.exec(req.headers.cookie || ''); if (!m) return null;
  const s = DB.sessions[m[1]]; if (!s || s.exp < Date.now()) return null;
  return byId(s.uid) || null;
}
const tries = {};
function hit(key, max) { const now = Date.now(), t = tries[key] = (tries[key] && now - tries[key].t < 6e5) ? tries[key] : { n: 0, t: now }; if (t.n >= max) throw err(429, 'Too many attempts. Try again in a few minutes.'); return t; }
function login(req, res, b) {
  const ip = clientIp(req), name = String(b.username || '').toLowerCase().trim(), now = Date.now();
  const a = hit('ip:' + ip, 20), c = hit('u:' + name, 10);
  const u = DB.users.find(x => x.username === name);
  if (!u || !checkPw(String(b.password || ''), u)) { a.n++; c.n++; throw err(401, 'Wrong username or password'); }
  delete tries['u:' + name];
  for (const k in DB.sessions) if (DB.sessions[k].exp < now) delete DB.sessions[k];
  const sid = crypto.randomBytes(32).toString('hex'); DB.sessions[sid] = { uid: u.id, exp: now + 12 * 36e5 }; save();
  const secure = SECURE || req.headers['x-forwarded-proto'] === 'https';
  res.setHeader('Set-Cookie', `sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${12 * 3600}${secure ? '; Secure' : ''}`);
  wait(res, 200, pub(u, true));
}
function body(req) {
  return new Promise((ok, no) => {
    let n = 0; const c = [];
    req.on('data', d => { n += d.length; if (n > 1.5e6) { no(err(413, 'Too large')); req.destroy(); } else c.push(d); });
    req.on('end', () => { try { ok(c.length ? JSON.parse(Buffer.concat(c)) : {}); } catch (e) { no(err(400, 'Bad JSON')); } });
  });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png' };
function serveStatic(p, res) {
  const f = path.normalize(path.join(PUB, p === '/' ? 'index.html' : p));
  if (!f.startsWith(PUB) || !fs.existsSync(f) || !fs.statSync(f).isFile()) throw err(404, 'Not found');
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'", 'Cache-Control': 'no-cache', ...(SECURE ? { 'Strict-Transport-Security': 'max-age=31536000' } : {}) });
  fs.createReadStream(f).pipe(res);
}
function userFields(b, forEdit) {
  const name = String(b.name || '').trim().slice(0, 80), designation = String(b.designation || '').trim().slice(0, 80), project = String(b.project || '').trim().slice(0, 160);
  const role = b.role; if (!['admin', 'supervisor', 'staff'].includes(role)) throw err(400, 'Invalid role');
  if (!name) throw err(400, 'Name is required');
  if (role !== 'admin' && (!designation || !project)) throw err(400, 'Designation and project are required');
  let supervisorId = null;
  if (role === 'staff') { const s = byId(b.supervisorId); if (!s || s.role !== 'supervisor') throw err(400, 'Choose a supervisor (add the supervisor first)'); if (s.project !== project) throw err(400, 'Supervisor must belong to the same project'); supervisorId = s.id; }
  return { name, designation, project, role, supervisorId };
}

/* ---------- API ---------- */
async function api(req, res, p, m) {
  if (m !== 'GET' && !/^application\/json/.test(req.headers['content-type'] || '')) throw err(415, 'JSON required');
  const b = m === 'GET' ? {} : await body(req);
  if (p === '/api/login' && m === 'POST') return login(req, res, b);
  const u = sessionUser(req); if (!u) throw err(401, 'Not signed in');
  const ok = o => wait(res, 200, o || { ok: true });

  if (p === '/api/logout' && m === 'POST') { const s = /sid=([a-f0-9]{64})/.exec(req.headers.cookie || ''); if (s) { delete DB.sessions[s[1]]; save(); } return ok(); }
  if (p === '/api/me' && m === 'GET') return ok(pub(u, true));
  if (p === '/api/password' && m === 'POST') {
    if (!checkPw(String(b.old || ''), u)) throw err(400, 'Current password is wrong');
    const pw = String(b.pw || ''); if (pw.length < 8) throw err(400, 'New password must be at least 8 characters'); if (pw === b.old) throw err(400, 'Choose a different password');
    Object.assign(u, hashPw(pw), { mustChange: false }); save(); return ok();
  }
  if (p === '/api/signature' && m === 'POST') {
    const s = String(b.sig || ''); if (!/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(s) || s.length > 400000) throw err(400, 'Invalid signature image');
    u.sig = s; save(); return ok();
  }
  if (u.mustChange) throw err(403, 'Change your password first');
  if (p === '/api/backup' && m === 'GET') { if (u.role !== 'admin') throw err(403, 'Admin only'); return ok({ exportedAt: new Date().toISOString(), users: DB.users, sheets: DB.sheets }); }

  /* people (admin) */
  if (p === '/api/users' && m === 'GET') { if (u.role !== 'admin') throw err(403, 'Admin only'); return ok(DB.users.map(x => pub(x))); }
  if (p === '/api/team' && m === 'GET') {
    if (u.role === 'staff') throw err(403, 'Not allowed');
    return ok(DB.users.filter(x => x.role === 'staff' && (u.role === 'admin' || x.project === u.project)).map(x => pub(x)));
  }
  if (p === '/api/users' && m === 'POST') {
    if (u.role !== 'admin') throw err(403, 'Admin only');
    const un = String(b.username || '').toLowerCase().trim(); if (!/^[a-z0-9._-]{3,30}$/.test(un)) throw err(400, 'Username: 3-30 letters, numbers, . _ -');
    if (DB.users.some(x => x.username === un)) throw err(400, 'Username already exists');
    if (String(b.password || '').length < 8) throw err(400, 'Password must be at least 8 characters');
    const n = { id: crypto.randomUUID(), username: un, sig: null, mustChange: true, createdAt: Date.now(), ...userFields(b), ...hashPw(String(b.password)) };
    DB.users.push(n); save(); return ok(pub(n));
  }
  let mm = p.match(/^\/api\/users\/([\w-]+)$/);
  if (mm) {
    if (u.role !== 'admin') throw err(403, 'Admin only'); const t = byId(mm[1]); if (!t) throw err(404, 'No such user');
    if (m === 'PUT') {
      Object.assign(t, userFields({ ...b, role: t.role === 'admin' ? 'admin' : b.role }));
      if (b.password) { if (String(b.password).length < 8) throw err(400, 'Password must be at least 8 characters'); Object.assign(t, hashPw(String(b.password)), { mustChange: true }); for (const k in DB.sessions) if (DB.sessions[k].uid === t.id) delete DB.sessions[k]; }
      if (b.clearSig) t.sig = null;
      save(); return ok(pub(t));
    }
    if (m === 'DELETE') {
      if (t.id === u.id) throw err(400, 'You cannot delete yourself');
      if (DB.users.some(x => x.supervisorId === t.id)) throw err(400, 'Reassign this supervisor’s staff first');
      DB.users = DB.users.filter(x => x.id !== t.id); for (const k in DB.sessions) if (DB.sessions[k].uid === t.id) delete DB.sessions[k]; save(); return ok();
    }
  }

  /* timesheets */
  if (p === '/api/timesheets' && m === 'GET') return ok(DB.sheets.filter(t => canSee(u, t)).map(summary));
  if (p === '/api/timesheets' && m === 'POST') {
    if (u.role !== 'staff') throw err(403, 'Only staff create timesheets');
    const s = byId(u.supervisorId); if (!s) throw err(400, 'No supervisor assigned. Ask the admin.');
    const t = { id: crypto.randomUUID(), ownerId: u.id, staffName: u.name, project: u.project, contract: u.designation, supervisorName: s.name, supDes: s.designation, status: 'draft', createdAt: Date.now(), updatedAt: Date.now(), ...cleanSheet(b) };
    DB.sheets.push(t); save(); return ok(t);
  }
  mm = p.match(/^\/api\/timesheets\/([\w-]+)(?:\/(submit|approve|reject))?$/);
  if (mm) {
    const t = DB.sheets.find(x => x.id === mm[1]); if (!t || !canSee(u, t)) throw err(404, 'Timesheet not found');
    const act = mm[2], mine = t.ownerId === u.id, editable = mine && (t.status === 'draft' || t.status === 'rejected');
    if (!act && m === 'GET') return ok(t);
    if (!act && m === 'PUT') { if (!editable) throw err(403, 'This timesheet is locked'); Object.assign(t, cleanSheet(b), { updatedAt: Date.now() }); save(); return ok(t); }
    if (!act && m === 'DELETE') { if (!mine || t.status !== 'draft') throw err(403, 'Only your drafts can be deleted'); DB.sheets = DB.sheets.filter(x => x !== t); save(); return ok(); }
    if (act === 'submit' && m === 'POST') {
      if (!editable) throw err(403, 'Already submitted'); if (!total(t)) throw err(400, 'Add some working hours first'); if (!t.pdate) throw err(400, 'Select your sign date first'); if (!u.sig) throw err(400, 'Upload your signature first');
      Object.assign(t, { status: 'pending', staffSig: u.sig, submittedAt: Date.now(), updatedAt: Date.now(), note: '' }); save(); return ok(t);
    }
    if ((act === 'approve' || act === 'reject') && m === 'POST') {
      if (u.role !== 'supervisor' || u.project !== t.project || t.status !== 'pending') throw err(403, 'You cannot decide on this timesheet');
      if (act === 'approve') { if (!D.test(b.sdate)) throw err(400, 'Select your sign date first'); if (!u.sig) throw err(400, 'Upload your signature first'); Object.assign(t, { status: 'approved', sdate: b.sdate, supSig: u.sig, note: String(b.note || '').slice(0, 300) }); }
      else { const n = String(b.note || '').trim().slice(0, 300); if (!n) throw err(400, 'Add a note explaining the rejection'); Object.assign(t, { status: 'rejected', note: n }); }
      Object.assign(t, { decidedBy: u.name, decidedAt: Date.now(), updatedAt: Date.now() }); save(); return ok(t);
    }
  }
  throw err(404, 'Not found');
}

http.createServer(async (req, res) => {
  try {
    const p = new URL(req.url, 'http://x').pathname;
    if (p === '/healthz') { res.writeHead(200); return res.end('ok'); }
    if (p.startsWith('/api/')) return await api(req, res, p, req.method);
    if (req.method !== 'GET') throw err(405, 'Method not allowed');
    serveStatic(decodeURIComponent(p), res);
  } catch (e) {
    if (!e.code) console.error(e);
    if (!res.headersSent) wait(res, typeof e.code === 'number' ? e.code : 500, { error: typeof e.code === 'number' ? e.message : 'Server error' });
  }
}).listen(PORT, HOST, () => console.log(`Timesheet Portal running on http://localhost:${PORT}  (listening on ${HOST})`));

# Deploying to the cloud

The app is one small Node process that stores data in a single file (`/data/db.json`).
So it needs: **one running copy only** and a **persistent disk** mounted at `/data`.
Any cloud that runs a Docker image and offers a persistent volume will do. Two easy routes are below.
Pick a region near you (Singapore or Mumbai) for the best speed from the Maldives.

Always set these before the first start:
* `ADMIN_PASSWORD`: first password for the `admin` user.
* `INITIAL_PASSWORD`: first password for the sample users (only if you keep them).
* `SEED_SAMPLE=0` if you do NOT want the four sample accounts created (you then add everyone yourself).
If you leave the passwords unset, random ones are created and printed once in the server log.
Everyone has to change their password at first sign-in anyway.

## Route A: Fly.io (simplest, HTTPS included)
1. Install flyctl and run `fly auth signup` (or `fly auth login`).
2. In this folder, edit `app = "..."` in `fly.toml` to a unique name.
3. `fly launch --no-deploy --copy-config`  (say no to a database)
4. `fly volumes create timesheet_data --size 1 --region sin`
5. `fly secrets set ADMIN_PASSWORD=YourLongPassword INITIAL_PASSWORD=AnotherOneTimePassword`
6. `fly deploy` then `fly scale count 1`
7. Open the `https://<app>.fly.dev` address. Add your own domain with `fly certs add portal.yourdomain.com`.

## Route B: any Linux server (VPS) with your own domain
1. Create a small Ubuntu server, point a DNS record (e.g. `timesheet.yourdomain.com`) to its IP.
2. Install Docker: `curl -fsSL https://get.docker.com | sh`
3. Copy this folder to the server, then `cp .env.example .env` and edit the three values.
4. `docker compose up -d --build`
Caddy gets the HTTPS certificate automatically. Updates: copy new files, run `docker compose up -d --build`.

## Other platforms (Render, Railway, Azure, AWS...)
Deploy the `Dockerfile`, attach a persistent disk/volume mounted at `/data`, keep the instance count at 1,
and set the environment variables above plus `TRUST_PROXY=1` and `COOKIE_SECURE=1` (already in the Dockerfile).
Platforms without a persistent disk (free tiers that sleep or reset) will lose your data. Don't use those.

## Backups
Sign in as admin, open **Manage people**, click **Download backup** regularly. Keep the file somewhere safe,
since it contains users, timesheets and signatures. Also use your provider's volume snapshots if available.

## Security checklist
* Use HTTPS only (both routes above do this).
* Change the admin password at first sign-in and use long passwords.
* Don't scale to more than one instance. Two copies would overwrite each other's data.
* Sign-in attempts are rate limited, sessions last 12 hours.

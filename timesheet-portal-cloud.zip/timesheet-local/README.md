# Timesheet Portal (self-hosted)

No installation of packages is needed. You only need **Node.js 18 or newer** (https://nodejs.org).

## Run it
    node server.js
Then open http://localhost:3000

Other computers on the same network can use `http://<this-computer-IP>:3000`.
Change the port with `PORT=8080 node server.js` (Windows PowerShell: `$env:PORT=8080; node server.js`).
Use `HOST=127.0.0.1` to allow access from this computer only.

## First sign-in
On the first run the admin account (`admin`) and four sample users (hamdhaan, hamdhoon, aiham, mariyam) are created.
Their passwords are random and printed once in the terminal, or set with the `ADMIN_PASSWORD` and `INITIAL_PASSWORD`
environment variables. Add `SEED_SAMPLE=0` to skip the sample users.
Everyone must choose a new password at first sign-in, and staff and supervisors must upload a signature image.

**Cloud hosting:** see `DEPLOY.md`.

## Adding people later
Sign in as admin, choose **Manage people**, and add supervisors first, then staff.
Give each person a username and a first password. Staff need a project and a supervisor.
Use **Edit** to change details or reset a password, **Clear signature** to make someone upload a new one.

## How access works
* Staff see and edit only their own timesheets.
* Supervisors see submitted timesheets and staff of **their own project only**, and can approve or reject them.
* Admin manages people and sees all submitted timesheets (read-only).
This is enforced on the server, not only in the page.

## Your data
Everything is stored in `data/db.json`. Back up that file regularly. Stop the server before copying it.
Passwords are stored as salted scrypt hashes. Sessions last 12 hours.

## Keeping it running
* Windows: create a Task Scheduler task that runs `node server.js` at startup in this folder.
* Linux/macOS: `npm i -g pm2 && pm2 start server.js --name timesheet && pm2 save && pm2 startup`

## HTTPS
The server speaks plain HTTP, which is fine on a trusted office network. If you expose it beyond that,
put it behind a reverse proxy with HTTPS (Caddy or nginx) so passwords are encrypted in transit.

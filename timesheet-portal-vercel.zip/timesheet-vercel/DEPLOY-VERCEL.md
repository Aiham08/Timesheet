# Deploy the Timesheet Portal on Vercel

How it works: the pages in `public/` are served as static files, `api/index.js` is one Vercel serverless function,
and all data is stored in a Neon Postgres database (a free tier is available through Vercel).

## Folder layout (this matters, it caused the 404 before)
The folder you deploy must have these directly inside it:

    api/index.js
    public/index.html  (+ app.js, style.css, emblem.png)
    package.json
    vercel.json

If your Git repo has an extra parent folder, set **Settings → General → Root Directory** to the folder that contains `vercel.json`.
Framework Preset must be **Other**. Leave Build Command and Output Directory empty.

## Steps
1. Put the folder in a GitHub repository (or use the Vercel CLI: `npx vercel` inside the folder).
2. In Vercel: **Add New → Project**, import the repository. Check the Root Directory and Framework as above. Deploy once.
3. Create the database: in your Vercel project open **Storage** (or the **Marketplace**), choose **Neon**, create a database
   and connect it to this project for all environments. Pick the **Singapore** region. This adds the `DATABASE_URL` variable automatically.
4. Add environment variables in **Settings → Environment Variables**:
   * `ADMIN_PASSWORD` : first password for the `admin` user (min. 8 characters)
   * `INITIAL_PASSWORD` : first password for the four sample users (min. 8 characters), or set `SEED_SAMPLE` to `0` to skip them
5. **Redeploy** (Deployments → the latest one → Redeploy) so the variables take effect.
6. Open your site, sign in as `admin` with `ADMIN_PASSWORD`, and choose a new password. Then use **Manage people** to add everyone.

The tables are created and the first accounts are added automatically on the first sign-in.
If you see "Setup needed" or "DATABASE_URL is not set" on the login page, step 3 or 4 is missing.

## Notes
* `vercel.json` runs the function in Singapore (`sin1`) to be close to a Singapore database. If your plan or database is elsewhere, change or delete the `regions` line.
* If visitors see a Vercel login page, turn off **Deployment Protection** for production in the project settings.
* Backups: **Manage people → Download backup** regularly. Neon also keeps a short history you can restore from.
* Passwords are stored as salted scrypt hashes, sessions last 12 hours, and repeated wrong passwords are blocked for a few minutes.
* Project separation is enforced in the API: a supervisor only sees staff and timesheets of their own project.

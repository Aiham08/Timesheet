'use strict';
const $ = id => document.getElementById(id);
const MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const MONL = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const esc = x => String(x == null ? '' : x).replace(/[&<>"']/g, c => '&#' + c.charCodeAt(0) + ';');
const iso = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
const parse = s => { const [a, b, c] = s.split('-').map(Number); return new Date(a, b - 1, c); };
const lab = d => d.getDate() + '-' + MON[d.getMonth()] + '-' + String(d.getFullYear()).slice(2);
const mins = t => { if (!t) return 0; const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const spent = r => { if (!r || r.off || !r.start || !r.end) return 0; const d = mins(r.end) - mins(r.start); return d > 0 ? d : 0; };
const hm = m => Math.floor(m / 60) + ':' + String(m % 60).padStart(2, '0');
const isWk = d => d.getDay() === 5 || d.getDay() === 6;
function daysOf(ps, pe) { const a = []; if (!ps || !pe) return a; const d = parse(ps), e = parse(pe); let n = 0; while (d <= e && n++ < 62) { a.push(new Date(d)); d.setDate(d.getDate() + 1); } return a; }
const sheetTotal = t => daysOf(t.ps, t.pe).reduce((s, d) => s + spent((t.rows || {})[iso(d)]), 0);
let ft; function flash(t) { const f = $('flash'); f.textContent = t; f.hidden = false; clearTimeout(ft); ft = setTimeout(() => f.hidden = true, 4000); }
const LBL = { draft: 'Draft', pending: 'Pending approval', approved: 'Approved', rejected: 'Rejected' };

async function api(method, url, body) {
  const r = await fetch(url, { method, credentials: 'same-origin', headers: method === 'GET' ? {} : { 'Content-Type': 'application/json' }, body: method === 'GET' ? undefined : JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || 'Request failed'), { status: r.status });
  return j;
}
function readSig(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader(); fr.onerror = () => rej(new Error('Could not read file'));
    fr.onload = () => { const im = new Image(); im.onerror = () => rej(new Error('Please choose an image file'));
      im.onload = () => { const w = Math.min(320, im.width), h = Math.max(1, Math.round(im.height * w / im.width)), c = document.createElement('canvas'); c.width = w; c.height = h;
        const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(im, 0, 0, w, h); res(c.toDataURL('image/jpeg', .85)); };
      im.src = fr.result; };
    fr.readAsDataURL(file);
  });
}

let ME, CUR, LIST = [], ED = false, SUPV = false, USERS = [], EDITING = null, SETUP_FORCED = true, poll;
const show = id => ['login', 'setup', 'app'].forEach(i => $(i).hidden = i !== id);

/* ---------- sign in / setup ---------- */
async function init() { try { ME = await api('GET', '/api/me'); route(); } catch (e) { show('login'); } }
function route() { if (ME.mustChange || (ME.role !== 'admin' && !ME.hasSig)) setupUI(true); else startApp(); }
$('lgo').onclick = async () => {
  $('lmsg').textContent = '';
  try { ME = await api('POST', '/api/login', { username: $('lu').value, password: $('lp').value }); $('lp').value = ''; route(); }
  catch (e) { $('lmsg').textContent = e.message; }
};
$('lp').onkeydown = e => { if (e.key === 'Enter') $('lgo').click(); };
function setupUI(forced) {
  SETUP_FORCED = forced; show('setup'); $('smsg').textContent = ''; $('sold').value = $('snew').value = ''; $('sfile').value = ''; $('sprev').innerHTML = '';
  const needPw = ME.mustChange || !forced, needSig = ME.role !== 'admin' && (!ME.hasSig || !forced);
  $('spw').hidden = !needPw; $('ssig').hidden = !needSig; $('scancel').hidden = forced;
  $('stitle').textContent = forced ? 'Finish setting up your login' : 'Change your password';
  $('ssub').textContent = forced ? [ME.mustChange ? 'Choose a new password.' : '', !ME.hasSig && ME.role !== 'admin' ? 'Upload your signature. It is placed in the Sign field of your timesheets.' : ''].join(' ') : '';
  $('ssig').hidden = !(ME.role !== 'admin' && !ME.hasSig && forced);
}
$('sfile').onchange = async e => { try { const s = await readSig(e.target.files[0]); $('sprev').innerHTML = '<img src="' + s + '" style="max-height:60px;background:#fff;border:1px solid var(--line);border-radius:6px" alt="">'; } catch (x) { $('smsg').textContent = x.message; } };
$('scancel').onclick = () => startApp();
$('sgo').onclick = async () => {
  const m = $('smsg'); m.textContent = '';
  try {
    if (!$('spw').hidden) await api('POST', '/api/password', { old: $('sold').value, pw: $('snew').value });
    if (!$('ssig').hidden) { const f = $('sfile').files[0]; if (!f) throw new Error('Please upload your signature image.'); await api('POST', '/api/signature', { sig: await readSig(f) }); }
    ME = await api('GET', '/api/me'); route();
  } catch (e) { m.textContent = e.message; }
};
$('bPw').onclick = () => setupUI(false);
$('bOut').onclick = async () => { try { await api('POST', '/api/logout'); } catch (e) {} clearInterval(poll); ME = null; $('lu').value = ''; show('login'); };
$('bSig').onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*';
  i.onchange = async () => { try { const s = await readSig(i.files[0]); await api('POST', '/api/signature', { sig: s }); ME.sig = s; flash('Signature updated'); } catch (x) { flash(x.message); } }; i.click(); };

/* ---------- home ---------- */
function startApp() {
  show('app'); const r = ME.role;
  $('who').textContent = ME.name + ' · ' + (r === 'staff' ? 'Part-time staff' : r === 'supervisor' ? 'Supervisor' : 'Admin') + (ME.project ? ' · ' + ME.project : '');
  $('bNew').hidden = r !== 'staff'; $('bTeam').hidden = r !== 'supervisor'; $('bPpl').hidden = r !== 'admin'; $('bSig').hidden = r === 'admin';
  $('home').hidden = false; $('editor').hidden = true; pane('list'); loadList();
  clearInterval(poll); poll = setInterval(() => { if (!$('home').hidden && !$('list').hidden) loadList(); }, 30000);
}
async function loadList() { try { LIST = await api('GET', '/api/timesheets'); renderList(); if (!$('team').hidden) renderTeam(); } catch (e) { if (e.status === 401) { show('login'); } else $('list').textContent = e.message; } }
function renderList() {
  const L = [...LIST].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)), staffView = ME.role === 'staff';
  if (!L.length) { $('list').innerHTML = '<p class="sub" style="margin:0">' + (staffView ? 'No timesheets yet. Click “New timesheet” to start a draft.' : 'No submitted timesheets yet.') + '</p>'; return; }
  $('list').innerHTML = '<table class="list"><thead><tr><th>Period</th>' + (staffView ? '<th>Approver</th>' : '<th>Staff</th>') + '<th>Hours</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>' +
    L.map((t, i) => `<tr><td>${lab(parse(t.ps))} – ${lab(parse(t.pe))}</td><td>${esc(staffView ? t.supervisorName : t.staffName)}</td><td>${hm(t.total)}</td><td><span class="badge b-${esc(t.status)}">${LBL[t.status] || ''}</span></td><td>${t.updatedAt ? new Date(t.updatedAt).toLocaleDateString() : ''}</td><td><button data-i="${i}">Open</button></td></tr>`).join('') + '</tbody></table>';
  $('list').querySelectorAll('button[data-i]').forEach(b => b.onclick = () => openId(L[+b.dataset.i].id));
}
function pane(n) {
  ['list', 'team', 'ppl'].forEach(i => $(i).hidden = i !== n);
  $('bPpl').textContent = n === 'ppl' ? 'Back to timesheets' : 'Manage people'; $('bTeam').textContent = n === 'team' ? 'Back to timesheets' : 'Project staff';
  if (n === 'ppl') renderPeople(); if (n === 'team') renderTeam(); if (n === 'list') loadList();
}
$('bPpl').onclick = () => pane($('ppl').hidden ? 'ppl' : 'list');
$('bTeam').onclick = () => pane($('team').hidden ? 'team' : 'list');
async function renderTeam() {
  try {
    const st = await api('GET', '/api/team');
    $('team').innerHTML = '<h2>' + esc(ME.project) + '</h2><p class="sub">Staff in your project only.</p>' + (st.length ? '<table class="list"><thead><tr><th>Name</th><th>Designation</th><th>Supervisor</th><th>Timesheets</th><th>Approved hours</th><th>Latest status</th></tr></thead><tbody>' + st.map(p => {
      const L = LIST.filter(t => t.ownerId === p.id).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)), h = L.filter(t => t.status === 'approved').reduce((a, t) => a + t.total, 0);
      return `<tr><td>${esc(p.name)}</td><td>${esc(p.designation)}</td><td>${esc(p.supervisorName)}</td><td>${L.length}</td><td>${hm(h)}</td><td>${L.length ? '<span class="badge b-' + esc(L[0].status) + '">' + LBL[L[0].status] + '</span>' : '—'}</td></tr>`;
    }).join('') + '</tbody></table>' : '<p class="sub">No staff added to this project yet.</p>');
  } catch (e) { $('team').textContent = e.message; }
}
$('bNew').onclick = () => {
  const n = new Date(), s = new Date(n.getFullYear(), n.getMonth() - (n.getDate() < 16 ? 1 : 0), 16), e = new Date(s.getFullYear(), s.getMonth() + 1, 15);
  if (!ME.supervisorName) { flash('No supervisor assigned. Ask the admin.'); return; }
  openSheet({ id: null, ownerId: ME.id, staffName: ME.name, project: ME.project, contract: ME.designation, supervisorName: ME.supervisorName, supDes: ME.supDes, ps: iso(s), pe: iso(e), req: 60, rows: {}, status: 'draft', pdate: '', sdate: '' });
};
async function openId(id) { try { openSheet(await api('GET', '/api/timesheets/' + id)); } catch (e) { flash(e.message); } }
$('bBack').onclick = () => { $('editor').hidden = true; $('home').hidden = false; loadList(); };

/* ---------- editor ---------- */
function openSheet(t) {
  CUR = JSON.parse(JSON.stringify(t)); $('home').hidden = true; $('editor').hidden = false;
  const mine = ME.role === 'staff' && CUR.ownerId === ME.id;
  ED = mine && (CUR.status === 'draft' || CUR.status === 'rejected');
  SUPV = ME.role === 'supervisor' && CUR.status === 'pending' && CUR.project === ME.project;
  if (SUPV && !CUR.sdate) CUR.sdate = iso(new Date());
  $('setupcard').hidden = !ED; $('approve').hidden = !SUPV; $('note').value = '';
  $('bSave').hidden = $('bSubmit').hidden = !ED; $('bDel').hidden = !(ED && CUR.id && CUR.status === 'draft'); $('bDel').textContent = 'Delete draft'; $('fs').hidden = !ED;
  const by = CUR.supervisorName;
  $('banner').textContent = CUR.status === 'draft' ? 'Draft. Not yet sent for approval.' : CUR.status === 'pending' ? 'Pending approval by ' + by + '.' : CUR.status === 'approved' ? 'Approved by ' + (CUR.decidedBy || by) + '.' : 'Rejected by ' + (CUR.decidedBy || by) + (CUR.note ? ': ' + CUR.note : '.') + (ED ? ' Edit and submit again.' : '');
  head(); build();
}
function head() {
  const ok = /^\d{4}-\d{2}-\d{2}$/;
  $('ps').value = CUR.ps; $('pe').value = CUR.pe; $('req').value = CUR.req;
  $('name').value = CUR.staffName; $('project').value = CUR.project || ''; $('contract').value = CUR.contract || '';
  $('sn').textContent = CUR.staffName; $('sdes').textContent = 'Designation: ' + (CUR.contract || '');
  $('sup').textContent = CUR.supervisorName; $('supdes').textContent = 'Designation: ' + (CUR.supDes || '');
  $('rq').textContent = CUR.req;
  $('pdate').value = ok.test(CUR.pdate) ? CUR.pdate : ''; $('sdate').value = ok.test(CUR.sdate) ? CUR.sdate : '';
  $('pdate').disabled = !ED; $('sdate').disabled = !SUPV;
  const a = parse(CUR.ps), b = parse(CUR.pe);
  $('pr').textContent = a.getDate() + ' ' + MONL[a.getMonth()] + ' - ' + b.getDate() + ' ' + MONL[b.getMonth()] + ' ' + b.getFullYear();
  const ss = (ED ? ME.sig : CUR.staffSig) || '', sp = CUR.status === 'approved' ? CUR.supSig || '' : '';
  $('sigS').hidden = !ss; if (ss) $('sigS').src = ss; $('sigP').hidden = !sp; if (sp) $('sigP').src = sp;
}
function rowOf(k, d) { const R = CUR.rows; if (!R[k]) R[k] = { detail: '', start: '', end: '', off: isWk(d) }; return R[k]; }
function build() {
  const tb = $('rows'); tb.innerHTML = '';
  daysOf(CUR.ps, CUR.pe).forEach(d => {
    const k = iso(d), r = rowOf(k, d), wk = isWk(d), tr = document.createElement('tr');
    if (!wk) r.off = false; tr.className = r.off ? 'off' : '';
    tr.innerHTML = '<td class="d">' + lab(d) + '</td><td><input data-f="detail"></td><td class="t"><input type="time" data-f="start"></td><td class="t"><input type="time" data-f="end"></td><td class="s"></td>';
    tr.querySelectorAll('input').forEach(i => { i.value = r[i.dataset.f]; i.disabled = !ED; i.addEventListener('input', () => { r[i.dataset.f] = i.value; upd(tr, r); totals(); }); });
    const dc = tr.querySelector('.d');
    if (ED && wk) { dc.style.cursor = 'pointer'; dc.title = 'Click to toggle working day';
      dc.onclick = () => { r.off = !r.off; if (r.off) { r.detail = r.start = r.end = ''; tr.querySelectorAll('input').forEach(i => i.value = ''); } tr.className = r.off ? 'off' : ''; upd(tr, r); totals(); }; }
    tb.appendChild(tr); upd(tr, r);
  });
  totals();
}
const upd = (tr, r) => tr.querySelector('.s').textContent = hm(spent(r));
function totals() {
  const t = sheetTotal(CUR); $('tot').textContent = hm(t); $('ft').textContent = hm(t) + ':00';
  const ok = t >= CUR.req * 60, el = $('status'); el.textContent = ok ? '✓ Requirement met (' + hm(t) + ' h)' : hm(t) + ' h · ' + hm(CUR.req * 60 - t) + ' h short of ' + CUR.req + ' h'; el.className = 'pill ' + (ok ? 'ok' : 'bad');
  $('met').textContent = ok ? 'This staff has met the requirements for payment for this period.' : '';
}
$('req').oninput = e => { CUR.req = Math.max(0, +e.target.value || 0); $('rq').textContent = CUR.req; totals(); };
['ps', 'pe'].forEach(id => $(id).onchange = e => { if (!e.target.value) return; CUR[id] = e.target.value; if (CUR.pe < CUR.ps) { flash('End date must be after the start date'); CUR[id] = id === 'ps' ? CUR.pe : CUR.ps; } head(); build(); });
$('pdate').onchange = e => CUR.pdate = e.target.value;
$('sdate').onchange = e => CUR.sdate = e.target.value;
$('fs').onclick = () => { daysOf(CUR.ps, CUR.pe).forEach(d => { if (isWk(d)) { const r = rowOf(iso(d), d); r.off = true; r.detail = r.start = r.end = ''; } }); build(); };
$('fill').onclick = () => { const f = $('qf').value, t = $('qt').value || f; daysOf(CUR.ps, CUR.pe).forEach(d => { const k = iso(d), r = CUR.rows[k]; if (f && (k < f || k > t)) return;
  if (r && !r.off && !r.start && !r.end && !r.detail) { r.detail = $('qd').value; r.start = $('qs').value; r.end = $('qe').value; } }); build(); };
$('prt').onclick = () => window.print();
$('csv').onclick = () => {
  const q = v => '"' + String(v).replace(/"/g, '""') + '"'; let o = 'Date,Details,Start,End,Time Spent\n';
  daysOf(CUR.ps, CUR.pe).forEach(d => { const r = CUR.rows[iso(d)]; o += [lab(d), q(r.detail), r.start, r.end, hm(spent(r))].join(',') + '\n'; }); o += ',,,Total,' + $('tot').textContent + '\n';
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([o], { type: 'text/csv' })); a.download = 'timesheet.csv'; a.click();
};

/* ---------- workflow ---------- */
async function persist() {
  const p = { ps: CUR.ps, pe: CUR.pe, req: CUR.req, pdate: CUR.pdate, rows: CUR.rows };
  const r = CUR.id ? await api('PUT', '/api/timesheets/' + CUR.id, p) : await api('POST', '/api/timesheets', p);
  CUR.id = r.id; CUR.status = r.status;
}
async function act(fn, okMsg, leave) { try { await fn(); flash(okMsg); if (leave) { $('editor').hidden = true; $('home').hidden = false; loadList(); } } catch (e) { flash('Failed: ' + e.message); } }
$('bSave').onclick = () => act(async () => { await persist(); $('bDel').hidden = CUR.status !== 'draft'; }, 'Draft saved');
$('bSubmit').onclick = () => {
  if (!sheetTotal(CUR)) { flash('Add some working hours first'); return; }
  if (!CUR.pdate) { flash('Select your sign date first'); return; }
  act(async () => { await persist(); await api('POST', '/api/timesheets/' + CUR.id + '/submit'); }, 'Sent to ' + CUR.supervisorName + ' for approval', true);
};
$('bDel').onclick = () => { const b = $('bDel'); if (b.textContent !== 'Really delete?') { b.textContent = 'Really delete?'; return; } act(() => api('DELETE', '/api/timesheets/' + CUR.id), 'Draft deleted', true); };
$('bOk').onclick = () => { if (!CUR.sdate) { flash('Select your sign date first'); return; } act(() => api('POST', '/api/timesheets/' + CUR.id + '/approve', { sdate: CUR.sdate, note: $('note').value }), 'Timesheet approved', true); };
$('bNo').onclick = () => { const n = $('note').value.trim(); if (!n) { flash('Please add a note explaining the rejection'); return; } act(() => api('POST', '/api/timesheets/' + CUR.id + '/reject', { note: n }), 'Timesheet rejected', true); };

/* ---------- admin: people ---------- */
function pform() {
  $('psupw').hidden = $('prole').value !== 'staff';
  const cur = $('psup').value;
  $('psup').innerHTML = USERS.filter(p => p.role === 'supervisor').map(p => `<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.project)})</option>`).join('');
  if (cur) $('psup').value = cur;
}
function resetForm() { EDITING = null; ['puser', 'ppw', 'pname', 'pdes', 'pproj'].forEach(i => $(i).value = ''); $('puser').disabled = $('prole').disabled = false; $('padd').textContent = 'Add person'; $('ppwl').textContent = 'First password'; $('pmsg').textContent = ''; }
$('prole').onchange = pform; $('pcancel').onclick = resetForm; $('pfilt').onchange = renderPeopleTable;
async function renderPeople() { try { USERS = await api('GET', '/api/users'); pform(); renderPeopleTable(); } catch (e) { $('plist').textContent = e.message; } }
function renderPeopleTable() {
  const cur = $('pfilt').value, pj = [...new Set(USERS.map(p => p.project).filter(Boolean))].sort();
  $('pfilt').innerHTML = '<option value="">All projects</option>' + pj.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join(''); $('pfilt').value = pj.includes(cur) ? cur : '';
  $('projlist').innerHTML = pj.map(x => `<option value="${esc(x)}">`).join('');
  const L = USERS.filter(p => !$('pfilt').value || p.project === $('pfilt').value).sort((a, b) => (a.project || '').localeCompare(b.project || '') || a.role.localeCompare(b.role) || a.name.localeCompare(b.name));
  const R = { admin: 'Admin', supervisor: 'Supervisor', staff: 'Staff' };
  $('plist').innerHTML = '<table class="list"><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Designation</th><th>Project / Supervisor</th><th>Signature</th><th></th></tr></thead><tbody>' + L.map((p, i) =>
    `<tr><td>${esc(p.name)}</td><td>${esc(p.username)}</td><td>${R[p.role]}</td><td>${esc(p.designation)}</td><td>${(p.project ? '<span class="sub">' + esc(p.project) + '</span>' : '') + (p.role === 'staff' ? '<br>' + esc(p.supervisorName) : '')}</td><td>${p.role === 'admin' ? '—' : p.hasSig ? 'Uploaded' : 'Missing'}</td><td style="white-space:nowrap"><button data-a="e" data-i="${i}">Edit</button> ${p.hasSig && p.role !== 'admin' ? `<button data-a="s" data-i="${i}">Clear signature</button> ` : ''}${p.id !== ME.id ? `<button class="d" data-a="d" data-i="${i}">Delete</button>` : ''}</td></tr>`).join('') + '</tbody></table>';
  $('plist').querySelectorAll('button[data-a]').forEach(b => b.onclick = () => pact(b.dataset.a, L[+b.dataset.i], b));
}
async function pact(a, p, b) {
  try {
    if (a === 'e') { EDITING = p.id; $('prole').value = p.role; pform(); $('puser').value = p.username; $('puser').disabled = true; $('prole').disabled = true; $('ppw').value = ''; $('ppwl').textContent = 'New password (leave blank to keep)';
      $('pname').value = p.name; $('pdes').value = p.designation || ''; $('pproj').value = p.project || ''; if (p.supervisorId) $('psup').value = p.supervisorId; $('padd').textContent = 'Save changes'; $('ppl').scrollIntoView(); return; }
    if (b.textContent !== 'Sure?') { b.textContent = 'Sure?'; return; }
    if (a === 's') { await api('PUT', '/api/users/' + p.id, { ...p, clearSig: true }); flash('Signature cleared. They must upload a new one.'); }
    else { await api('DELETE', '/api/users/' + p.id); flash('Removed'); }
    renderPeople();
  } catch (e) { flash('Failed: ' + e.message); }
}
$('padd').onclick = async () => {
  const m = $('pmsg'); m.textContent = '';
  const d = { role: $('prole').value, username: $('puser').value, password: $('ppw').value, name: $('pname').value, designation: $('pdes').value, project: $('pproj').value, supervisorId: $('psup').value };
  try {
    if (EDITING) await api('PUT', '/api/users/' + EDITING, d); else await api('POST', '/api/users', d);
    flash(EDITING ? 'Changes saved' : 'Person added'); resetForm(); renderPeople();
  } catch (e) { m.textContent = e.message; }
};

$('pbak').onclick = async () => { try { const d = await api('GET', '/api/backup'); const x = document.createElement('a'); x.href = URL.createObjectURL(new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' })); x.download = 'timesheet-backup-' + new Date().toISOString().slice(0, 10) + '.json'; x.click(); } catch (e) { flash(e.message); } };

init();

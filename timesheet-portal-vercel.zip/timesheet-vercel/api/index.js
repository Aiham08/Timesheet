'use strict';
/* Timesheet Portal API for Vercel (serverless) + Neon Postgres.
   Env vars: DATABASE_URL (set by the Neon integration), ADMIN_PASSWORD, INITIAL_PASSWORD (or SEED_SAMPLE=0). */
const crypto = require('crypto');

const err = (code, msg) => Object.assign(new Error(msg), { code });

/* ---------- database ---------- */
let _sql = null;
function sqlFn() {
  if (_sql) return _sql;
  if (global.__TS_SQL) return (_sql = global.__TS_SQL);            // test hook
  const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  if (!url) throw err(500, 'DATABASE_URL is not set. Connect a Neon database to this Vercel project.');
  const { neon } = require('@neondatabase/serverless');
  const n = neon(url);
  return (_sql = (t, p) => n.query(t, p || []));
}
const q = (t, p) => sqlFn()(t, p || []);

let readyP = null;
function ready() {
  return readyP || (readyP = (async () => {
    await q('CREATE TABLE IF NOT EXISTS users(id text PRIMARY KEY, username text UNIQUE NOT NULL, data jsonb NOT NULL, sig text)');
    await q('CREATE TABLE IF NOT EXISTS sheets(id text PRIMARY KEY, owner_id text NOT NULL, project text, status text, data jsonb NOT NULL, staff_sig text, sup_sig text)');
    await q('CREATE TABLE IF NOT EXISTS sessions(sid text PRIMARY KEY, uid text NOT NULL, exp bigint NOT NULL)');
    await q('CREATE TABLE IF NOT EXISTS attempts(k text PRIMARY KEY, n integer NOT NULL, t bigint NOT NULL)');
    await seed();
  })().catch(e => { readyP = null; throw e; }));
}

/* ---------- passwords / users ---------- */
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, hash: crypto.scryptSync(pw, salt, 64).toString('hex') });
const checkPw = (pw, u) => { const a = crypto.scryptSync(pw, u.salt, 64), b = Buffer.from(u.hash, 'hex'); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const mkUser = (username, pw, role, name, designation, project, supervisorId) =>
  ({ id: 'u-' + username, username, role, name, designation, project, supervisorId: supervisorId || null, mustChange: true, createdAt: Date.now(), sig: null, ...hashPw(pw) });
const strip = u => { const { sig, hasSig, ...d } = u; return d; };
const fromRow = r => r ? { ...r.data, sig: r.sig || null, hasSig: !!r.sig } : null;
async function getUser(id) { return fromRow((await q('SELECT data, sig FROM users WHERE id=$1', [id]))[0]); }
async function getUserByName(un) { return fromRow((await q('SELECT data, sig FROM users WHERE username=$1', [un]))[0]); }
async function listUsers() { return (await q('SELECT data, (sig IS NOT NULL) AS has_sig FROM users', [])).map(r => ({ ...r.data, sig: null, hasSig: !!r.has_sig })); }
const insertUser = (u, quiet) => q('INSERT INTO users(id, username, data, sig) VALUES($1,$2,$3::jsonb,$4)' + (quiet ? ' ON CONFLICT (id) DO NOTHING' : ''), [u.id, u.username, JSON.stringify(strip(u)), u.sig || null]);
const saveUser = u => q('UPDATE users SET data=$2::jsonb, sig=$3 WHERE id=$1', [u.id, JSON.stringify(strip(u)), u.sig || null]);

async function seed() {
  const c = await q('SELECT count(*) AS n FROM users', []);
  if (Number(c[0].n) > 0) return;
  const A = process.env.ADMIN_PASSWORD, I = process.env.INITIAL_PASSWORD, sample = process.env.SEED_SAMPLE !== '0';
  if (!A || A.length < 8) throw err(500, 'Setup needed: add the ADMIN_PASSWORD environment variable (at least 8 characters) in Vercel, then redeploy.');
  if (sample && (!I || I.length < 8)) throw err(500, 'Setup needed: add INITIAL_PASSWORD (at least 8 characters), or set SEED_SAMPLE=0, then redeploy.');
  const P1 = 'Enhancing Climate Change and Food Security Project (ECRFS project)';
  const P2 = 'Toward Risk-Aware and Climate-resilienT communities (TRACT) project';
  await insertUser(mkUser('admin', A, 'admin', 'Administrator', '', ''), true);
  if (!sample) return;
  const s1 = mkUser('hamdhaan', I, 'supervisor', 'Mohamed Hamdhaan Zuhair', 'Project Manager', P1);
  const s2 = mkUser('hamdhoon', I, 'supervisor', 'Mohamed Hamdhoon', 'Project Manager', P2);
  for (const u of [s1, s2, mkUser('aiham', I, 'staff', 'Abdulla Aiham Mohamed', 'Procurement Specialist', P1, s1.id), mkUser('mariyam', I, 'staff', 'Mariyam Fazula', 'Procurement Officer', P2, s2.id)]) await insertUser(u, true);
}

function pub(u, m, withSig) {
  const o = { id: u.id, username: u.username, role: u.role, name: u.name, designation: u.designation, project: u.project, supervisorId: u.supervisorId, mustChange: !!u.mustChange, hasSig: !!u.hasSig };
  if (u.role === 'staff') { const s = m[u.supervisorId]; o.supervisorName = s ? s.name : ''; o.supDes = s ? s.designation : ''; }
  if (withSig) o.sig = u.sig; return o;
}
const meView = async u => { const m = {}; if (u.supervisorId) { const s = await getUser(u.supervisorId); if (s) m[s.id] = s; } return pub(u, m, true); };
const mapOf = L => Object.fromEntries(L.map(x => [x.id, x]));

/* ---------- timesheets ---------- */
const D = /^\d{4}-\d{2}-\d{2}$/, T = /^([01]\d|2[0-3]):[0-5]\d$/;
const mins = t => { if (!T.test(t)) return 0; const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const spent = r => (!r || r.off || !r.start || !r.end) ? 0 : Math.max(0, mins(r.end) - mins(r.start));
function dayList(ps, pe) { const o = []; for (let a = Date.parse(ps + 'T00:00:00Z'), b = Date.parse(pe + 'T00:00:00Z'); a <= b && o.length < 63; a += 864e5) o.push(new Date(a).toISOString().slice(0, 10)); return o; }
const total = t => dayList(t.ps, t.pe).reduce((s, d) => s + spent((t.rows || {})[d]), 0);
function cleanSheet(b) {
  if (!D.test(b.ps) || !D.test(b.pe) || isNaN(Date.parse(b.ps)) || isNaN(Date.parse(b.pe)) || b.pe < b.ps) throw err(400, 'Invalid period');
  const days = dayList(b.ps, b.pe); if (days.length > 62) throw err(400, 'Period too long');
  const rows = {}; for (const d of days) { const r = (b.rows || {})[d] || {}; rows[d] = { detail: String(r.detail || '').slice(0, 200), start: T.test(r.start) ? r.start : '', end: T.test(r.end) ? r.end : '', off: !!r.off }; }
  return { ps: b.ps, pe: b.pe, req: Math.min(744, Math.max(0, +b.req || 0)), pdate: D.test(b.pdate) ? b.pdate : '', rows };
}
const sheetRow = r => r ? { ...r.data, staffSig: r.staff_sig || undefined, supSig: r.sup_sig || undefined } : null;
const getSheet = async id => sheetRow((await q('SELECT data, staff_sig, sup_sig FROM sheets WHERE id=$1', [id]))[0]);
const sheetData = t => { const { staffSig, supSig, ...d } = t; return JSON.stringify(d); };
const insertSheet = t => q('INSERT INTO sheets(id, owner_id, project, status, data, staff_sig, sup_sig) VALUES($1,$2,$3,$4,$5::jsonb,$6,$7)', [t.id, t.ownerId, t.project, t.status, sheetData(t), t.staffSig || null, t.supSig || null]);
const saveSheet = t => q('UPDATE sheets SET project=$2, status=$3, data=$4::jsonb, staff_sig=$5, sup_sig=$6 WHERE id=$1', [t.id, t.project, t.status, sheetData(t), t.staffSig || null, t.supSig || null]);
const summary = t => ({ id: t.id, ownerId: t.ownerId, staffName: t.staffName, supervisorName: t.supervisorName, project: t.project, ps: t.ps, pe: t.pe, status: t.status, total: total(t), updatedAt: t.updatedAt });
const canSee = (u, t) => u.role === 'admin' ? t.status !== 'draft' : t.ownerId === u.id || (u.role === 'supervisor' && t.status !== 'draft' && t.project === u.project);
async function listSheets(u) {
  const rows = u.role === 'admin' ? await q("SELECT data FROM sheets WHERE status <> 'draft'", [])
    : u.role === 'supervisor' ? await q("SELECT data FROM sheets WHERE owner_id=$1 OR (project=$2 AND status <> 'draft')", [u.id, u.project || ''])
    : await q('SELECT data FROM sheets WHERE owner_id=$1', [u.id]);
  return rows.map(r => r.data);
}

/* ---------- http helpers ---------- */
const send = (res, c, o) => { res.statusCode = c; res.setHeader('Content-Type', 'application/json'); res.setHeader('Cache-Control', 'no-store'); res.end(JSON.stringify(o)); };
function readBody(req) {
  if (req.body !== undefined && req.body !== null) { try { return Promise.resolve(typeof req.body === 'string' ? (req.body ? JSON.parse(req.body) : {}) : (Buffer.isBuffer(req.body) ? JSON.parse(req.body.toString() || '{}') : req.body)); } catch (e) { return Promise.reject(err(400, 'Bad JSON')); } }
  return new Promise((ok, no) => {
    let n = 0; const c = [];
    req.on('data', d => { n += d.length; if (n > 1.5e6) no(err(413, 'Too large')); else c.push(d); });
    req.on('end', () => { try { ok(c.length ? JSON.parse(Buffer.concat(c)) : {}); } catch (e) { no(err(400, 'Bad JSON')); } });
  });
}
const clientIp = req => String(req.headers['x-real-ip'] || req.headers['x-forwarded-for'] || (req.socket && req.socket.remoteAddress) || '').split(',')[0].trim();
const sidOf = req => { const m = /(?:^|;\s*)sid=([a-f0-9]{64})/.exec(req.headers.cookie || ''); return m ? m[1] : null; };
async function sessionUser(req) {
  const sid = sidOf(req); if (!sid) return null;
  const r = await q('SELECT uid FROM sessions WHERE sid=$1 AND exp > $2', [sid, Date.now()]);
  return r[0] ? getUser(r[0].uid) : null;
}
async function hit(key, max) {
  const now = Date.now(), r = (await q('SELECT n, t FROM attempts WHERE k=$1', [key]))[0];
  const live = r && now - Number(r.t) < 6e5, a = { key, n: live ? r.n : 0, t: live ? Number(r.t) : now };
  if (a.n >= max) throw err(429, 'Too many attempts. Try again in a few minutes.'); return a;
}
const bump = a => q('INSERT INTO attempts(k, n, t) VALUES($1,$2,$3) ON CONFLICT (k) DO UPDATE SET n=$2, t=$3', [a.key, a.n + 1, a.t]);

async function login(req, res, b) {
  const name = String(b.username || '').toLowerCase().trim(), now = Date.now();
  const a = await hit('ip:' + clientIp(req), 20), c = await hit('u:' + name, 10);
  const u = name ? await getUserByName(name) : null;
  if (!u || !checkPw(String(b.password || ''), u)) { await bump(a); await bump(c); throw err(401, 'Wrong username or password'); }
  await q('DELETE FROM attempts WHERE k=$1', ['u:' + name]); await q('DELETE FROM sessions WHERE exp < $1', [now]);
  const sid = crypto.randomBytes(32).toString('hex');
  await q('INSERT INTO sessions(sid, uid, exp) VALUES($1,$2,$3)', [sid, u.id, now + 12 * 36e5]);
  const secure = !!process.env.VERCEL || req.headers['x-forwarded-proto'] === 'https';
  res.setHeader('Set-Cookie', `sid=${sid}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${12 * 3600}${secure ? '; Secure' : ''}`);
  send(res, 200, await meView(u));
}
function userFields(b, sup) {
  const name = String(b.name || '').trim().slice(0, 80), designation = String(b.designation || '').trim().slice(0, 80), project = String(b.project || '').trim().slice(0, 160), role = b.role;
  if (!['admin', 'supervisor', 'staff'].includes(role)) throw err(400, 'Invalid role');
  if (!name) throw err(400, 'Name is required');
  if (role !== 'admin' && (!designation || !project)) throw err(400, 'Designation and project are required');
  let supervisorId = null;
  if (role === 'staff') { if (!sup || sup.role !== 'supervisor') throw err(400, 'Choose a supervisor (add the supervisor first)'); if (sup.project !== project) throw err(400, 'Supervisor must belong to the same project'); supervisorId = sup.id; }
  return { name, designation, project, role, supervisorId };
}

/* ---------- routes ---------- */
async function route(req, res, p, m) {
  if (m !== 'GET' && !/^application\/json/.test(req.headers['content-type'] || '')) throw err(415, 'JSON required');
  const b = m === 'GET' ? {} : await readBody(req);
  await ready();
  if (p === '/api/login' && m === 'POST') return login(req, res, b);
  const u = await sessionUser(req); if (!u) throw err(401, 'Not signed in');
  const ok = o => send(res, 200, o || { ok: true });

  if (p === '/api/logout' && m === 'POST') { const s = sidOf(req); if (s) await q('DELETE FROM sessions WHERE sid=$1', [s]); return ok(); }
  if (p === '/api/me' && m === 'GET') return ok(await meView(u));
  if (p === '/api/password' && m === 'POST') {
    if (!checkPw(String(b.old || ''), u)) throw err(400, 'Current password is wrong');
    const pw = String(b.pw || ''); if (pw.length < 8) throw err(400, 'New password must be at least 8 characters'); if (pw === b.old) throw err(400, 'Choose a different password');
    Object.assign(u, hashPw(pw), { mustChange: false }); await saveUser(u); return ok();
  }
  if (p === '/api/signature' && m === 'POST') {
    const s = String(b.sig || ''); if (!/^data:image\/(jpeg|png);base64,[A-Za-z0-9+/=]+$/.test(s) || s.length > 400000) throw err(400, 'Invalid signature image');
    u.sig = s; await saveUser(u); return ok();
  }
  if (u.mustChange) throw err(403, 'Change your password first');

  if (p === '/api/backup' && m === 'GET') {
    if (u.role !== 'admin') throw err(403, 'Admin only');
    const us = (await q('SELECT data, sig FROM users', [])).map(r => ({ ...r.data, sig: r.sig })), sh = (await q('SELECT data, staff_sig, sup_sig FROM sheets', [])).map(sheetRow);
    return ok({ exportedAt: new Date().toISOString(), users: us, sheets: sh });
  }
  if (p === '/api/users' && m === 'GET') { if (u.role !== 'admin') throw err(403, 'Admin only'); const L = await listUsers(), M = mapOf(L); return ok(L.map(x => pub(x, M))); }
  if (p === '/api/team' && m === 'GET') {
    if (u.role === 'staff') throw err(403, 'Not allowed');
    const L = await listUsers(), M = mapOf(L); return ok(L.filter(x => x.role === 'staff' && (u.role === 'admin' || x.project === u.project)).map(x => pub(x, M)));
  }
  if (p === '/api/users' && m === 'POST') {
    if (u.role !== 'admin') throw err(403, 'Admin only');
    const un = String(b.username || '').toLowerCase().trim(); if (!/^[a-z0-9._-]{3,30}$/.test(un)) throw err(400, 'Username: 3-30 letters, numbers, . _ -');
    if (await getUserByName(un)) throw err(400, 'Username already exists');
    if (String(b.password || '').length < 8) throw err(400, 'Password must be at least 8 characters');
    const n = { id: 'u-' + un + '-' + crypto.randomBytes(3).toString('hex'), username: un, sig: null, mustChange: true, createdAt: Date.now(), ...userFields(b, b.supervisorId ? await getUser(b.supervisorId) : null), ...hashPw(String(b.password)) };
    await insertUser(n); const M = {}; if (n.supervisorId) M[n.supervisorId] = await getUser(n.supervisorId); return ok(pub(n, M));
  }
  let mm = p.match(/^\/api\/users\/([\w-]+)$/);
  if (mm) {
    if (u.role !== 'admin') throw err(403, 'Admin only'); const t = await getUser(mm[1]); if (!t) throw err(404, 'No such user');
    if (m === 'PUT') {
      Object.assign(t, userFields({ ...b, role: t.role === 'admin' ? 'admin' : b.role }, b.supervisorId ? await getUser(b.supervisorId) : null));
      if (b.password) { if (String(b.password).length < 8) throw err(400, 'Password must be at least 8 characters'); Object.assign(t, hashPw(String(b.password)), { mustChange: true }); await q('DELETE FROM sessions WHERE uid=$1', [t.id]); }
      if (b.clearSig) t.sig = null;
      await saveUser(t); return ok({ ok: true });
    }
    if (m === 'DELETE') {
      if (t.id === u.id) throw err(400, 'You cannot delete yourself');
      if ((await listUsers()).some(x => x.supervisorId === t.id)) throw err(400, 'Reassign this supervisor’s staff first');
      await q('DELETE FROM users WHERE id=$1', [t.id]); await q('DELETE FROM sessions WHERE uid=$1', [t.id]); return ok();
    }
  }

  if (p === '/api/timesheets' && m === 'GET') return ok((await listSheets(u)).map(summary));
  if (p === '/api/timesheets' && m === 'POST') {
    if (u.role !== 'staff') throw err(403, 'Only staff create timesheets');
    const s = u.supervisorId ? await getUser(u.supervisorId) : null; if (!s) throw err(400, 'No supervisor assigned. Ask the admin.');
    const t = { id: crypto.randomUUID(), ownerId: u.id, staffName: u.name, project: u.project, contract: u.designation, supervisorName: s.name, supDes: s.designation, status: 'draft', createdAt: Date.now(), updatedAt: Date.now(), ...cleanSheet(b) };
    await insertSheet(t); return ok(t);
  }
  mm = p.match(/^\/api\/timesheets\/([\w-]+)(?:\/(submit|approve|reject))?$/);
  if (mm) {
    const t = await getSheet(mm[1]); if (!t || !canSee(u, t)) throw err(404, 'Timesheet not found');
    const act = mm[2], mine = t.ownerId === u.id, editable = mine && (t.status === 'draft' || t.status === 'rejected');
    if (!act && m === 'GET') return ok(t);
    if (!act && m === 'PUT') { if (!editable) throw err(403, 'This timesheet is locked'); Object.assign(t, cleanSheet(b), { updatedAt: Date.now() }); await saveSheet(t); return ok(t); }
    if (!act && m === 'DELETE') { if (!mine || t.status !== 'draft') throw err(403, 'Only your drafts can be deleted'); await q('DELETE FROM sheets WHERE id=$1', [t.id]); return ok(); }
    if (act === 'submit' && m === 'POST') {
      if (!editable) throw err(403, 'Already submitted'); if (!total(t)) throw err(400, 'Add some working hours first'); if (!t.pdate) throw err(400, 'Select your sign date first'); if (!u.sig) throw err(400, 'Upload your signature first');
      Object.assign(t, { status: 'pending', staffSig: u.sig, submittedAt: Date.now(), updatedAt: Date.now(), note: '' }); await saveSheet(t); return ok(t);
    }
    if ((act === 'approve' || act === 'reject') && m === 'POST') {
      if (u.role !== 'supervisor' || u.project !== t.project || t.status !== 'pending') throw err(403, 'You cannot decide on this timesheet');
      if (act === 'approve') { if (!D.test(b.sdate)) throw err(400, 'Select your sign date first'); if (!u.sig) throw err(400, 'Upload your signature first'); Object.assign(t, { status: 'approved', sdate: b.sdate, supSig: u.sig, note: String(b.note || '').slice(0, 300) }); }
      else { const n = String(b.note || '').trim().slice(0, 300); if (!n) throw err(400, 'Add a note explaining the rejection'); Object.assign(t, { status: 'rejected', note: n }); }
      Object.assign(t, { decidedBy: u.name, decidedAt: Date.now(), updatedAt: Date.now() }); await saveSheet(t); return ok(t);
    }
  }
  throw err(404, 'Not found');
}

module.exports = async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const p = url.searchParams.has('__p') ? '/api/' + url.searchParams.get('__p').replace(/^\/+/, '') : url.pathname;
    await route(req, res, p.replace(/\/+$/, '') || '/', req.method);
  } catch (e) {
    if (typeof e.code !== 'number') console.error(e);
    if (!res.headersSent) send(res, typeof e.code === 'number' ? e.code : 500, { error: typeof e.code === 'number' ? e.message : 'Server error' });
  }
};

# Timesheet Portal (Vercel + Neon Postgres)
See DEPLOY-VERCEL.md for the full setup. Required environment variables: DATABASE_URL (from the Neon integration),
ADMIN_PASSWORD, and INITIAL_PASSWORD (or SEED_SAMPLE=0).
